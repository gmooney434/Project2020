﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project2020.ViewModels
{
    public class StayEditViewModel : CreateStayViewModel
    {
        public int StayId { get; set; }
    }
}
